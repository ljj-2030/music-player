<template>
    <div>
        <div class="comment" >
            <h2>评论</h2>
            <div class="comment-msg">
                <div class="comment-img">
                    <img :src="attachImgUrl(avator)" />
                </div>
                <el-input class="comment-input" type="textarea" :rows="2" placeholder="请输入内容" v-model="text"></el-input>
            </div>
            <el-button type="primary" class="sub-btn" @click="postComment">评论</el-button>
        </div>
        <p>精彩评论：共{{commentList.length}}条评论</p>
        <ul class="popular" v-for="(item,index) in commentList" :key="index">
            <li>
                <div class="popular-img">
                    <img :src="attachImgUrl(userPic[index])" alt="">
                </div>
                <div class="popular-msg">
                    <ul>
                        <li class="name">{{userName[index]}}</li>
                        <li class="time">{{item.createTime}}</li>
                        <li class="content">{{item.content}}</li>
                    </ul>
                </div>
                <div class="up" ref="up" @click="postUp(item.id,item.up,index)">
                    <svg class="icon">
                        <use xlink:href="#icon-zan"></use>
                    </svg>
                    {{item.up}}
                </div>
            </li>
        </ul>

    </div>
</template>
<script>
import {setComment,commentOfSongListId,commentOfSongId,getUser,setLike} from "../api/index"
import{minx} from "../mixins"
import{mapGetters} from "vuex"
export default {
    props:[
        'playId',//歌单或歌曲id
        'type',//评论类型
    ],
    data(){return{
            text:'',//存放输入的内容
            commentList:[],
            userPic:[],
            userName:[],
    }},
    created(){
        if(this.type===1){
            this.getSongListComment();
        }else{
            this.getSongComment();
        }
    

    },
    methods:{
        //提交评论
        postComment(){
            if(this.loginIn){
                let params=new URLSearchParams();
                if(this.type==1){//歌单
                params.append("songListId",this.playId)
                }else{
                //歌曲
                params.append("songId",this.playId)
                }
                params.append("userId",this.userId)
                params.append("type",this.type)
                params.append("content",this.text)
                setComment(params).then(res=>{
                    if(res.code===1){
                        this.$message.success("评论成功")
                        this.text=''
                        if(this.type===1){
                            this.getSongListComment();
                        }else{
                            this.getSongComment();
                        }
                    }else{
                        this.$message.error("评论失败!")
                    }
                }).catch(err=>{
                    this.$message.error("评论失败")
                })
            }else{
                this.$message.error("请先去登录")
            }
        },
        getSongListComment(){
            commentOfSongListId(this.playId).then(res=>{
               this.commentList=res;
               for(let comment of this.commentList){
                  getUser(comment.userId).then(res=>{
                   this.userPic.push(res.avator)
                 this.userName.push(res.username)
        })
    }
            })
        },
        getSongComment(){
                commentOfSongId(this.playId).then(res=>{
                    this.commentList=res;      
                    for(let comment of this.commentList){
                     getUser(comment.userId).then(res=>{
                     this.userPic.push(res.avator)
                              this.userName.push(res.username)
                  })
              }
                })
        },
        //点赞
        postUp(id,up,index){
                let params=new URLSearchParams();
                params.append("id",id);
                params.append("up",up+1)
                setLike(params).then(res=>{
                    if(res>0){ 
                        if(this.type===1){
                            this.getSongListComment();
                        }else{
                            this.getSongComment();
                        }
                    this.$refs.up[index].children[0].style.color="#2796cd"
                    }
                })
        }

        
    },
    mixins:[minx],
    computed:{
        ...mapGetters([
            'id',//
            'loginIn',
            'userId',
            'avator'
      
        ])
    }
}
</script>
<style lang="scss" scoped>
@import"../assets/css/comment.scss";
.up:hover{
    cursor: pointer;
}
</style>