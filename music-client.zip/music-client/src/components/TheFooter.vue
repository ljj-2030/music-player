<template>
    <div class="the-footer">
        <p>关于| 帮助 | 条款 | 反馈 |</p>
        <p>Copyright @2020</p>
    </div>
</template>
<style lang="scss" scoped>
@import "../assets/css/the-footer.scss"

</style>