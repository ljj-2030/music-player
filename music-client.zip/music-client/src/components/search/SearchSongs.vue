<template>
<div class="search-songs">
    <album :songList="listOfSongs"/>
</div>
    
</template>
<script>
import{mapGetters} from "vuex"
import Album from "../Album.vue"
import {minx} from "../../mixins"
export default {
    mounted(){
        this.getSong();
    },
    mixins:[minx],
    computed:{
        ...mapGetters([
            'listOfSongs',
        ])
    },
    components:{
        Album,
    }
}
</script>