<template>
    <div class="search-song-Lists">
        <content-list :contentList="albumDatas">
        </content-list>
    </div>
</template>
<script>
import ContentList from "../../components/ContentList.vue"
import {songListLikeTitle} from "../../api/index"
import{mapGetters} from "vuex"
export default {
    components:{
        ContentList,
    },
    computed:{
        ...mapGetters([
            'keywords',//搜索的内容
        ])
    },
    created(){
        this.title=this.keywords
        this.getSongListLikeTitle();
    },
    data(){
        return{
                albumDatas:[],
                title:'',//查询的内容

        }
    },


    methods:{
        getSongListLikeTitle(){
                if(!this.title||(this.title==='')){
                    this.$message.error("没有搜索信息!")
                    return;
                }
                console.log(this.title,"============")
                songListLikeTitle(this.title).then(res=>{
                   if(res){
                        this.albumDatas=res;
                   }else{
                       this.$message.error("暂无该信息")
                   }
                })

        }
    }
    
}
</script>
<style lang="scss" scoped>
@import"../../assets/css/search-song-lists.scss";
</style>