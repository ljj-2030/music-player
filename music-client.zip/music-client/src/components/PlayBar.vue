<template>
    <div class="play-bar" :class="{show:!toggle}">
        <div class="item-up" @click="toggle=!toggle" :class="{turn:toggle}">
            <svg class="icon">
                <use xlink:href="#icon-jiantou-xia-cuxiantiao"></use>
            </svg>
        </div>
        <div class="kongjian">
            <!--上一首-->
            <div class="item" @click="prev">
                <svg class="icon">
                    <use xlink:href="#icon-ziyuanldpi"></use>
                </svg>
            </div>
            <!-- 播放 -->
             <div class="item" @click="togglePlay">
                <svg class="icon">
                    <use :xlink:href="playButton"></use>
                </svg>
            </div>
            <!--下一首-->
             <div class="item" @click="next">
                <svg class="icon">
                    <use xlink:href="#icon-ziyuanldpi1"></use>
                </svg>
            </div>
            <!--歌曲图片-->
            <div class="item-img" @click="toLyric">
                <img :src="picUrl" alt="">
            </div>
            <!--播放进度-->
            <div class="playing-speed">
                <!-- 播放开始时间 -->
                <div class="current-time">{{nowTime}}</div>
                <div class="progress-box">
                    <div class="item-song-title">
                        <div>{{title}}</div>
                        <div>{{artist}}</div>
                    </div>
                    <div class="progress" ref="progress" @mousemove="mousemove"  @mouseup="mouseout" @click="updatemove">
                        <!-- 进度条 -->
                        <div class="bg" ref="bg">
                            <div class="cur-progress" ref="curProgress" :style="{width:curLength+'%'}"></div>
                        </div>
                        <!-- 拖动的点点 -->
                        <div class="idot" ref="idot" :style="{left:curLength+'%'}" @mousedown="mousedown"></div>
                    </div>
                </div>
                <!-- 播放结束时间 -->
                <div class="left-time">{{songTime}}</div>
                <!-- 音量 -->
                <div class="item item-volume">
                    <svg class="icon" v-if="volume!=0">
                        <use xlink:href="#icon-yinliang1"></use>
                    </svg>

                    <svg class="icon" v-else>
                        <use xlink:href="#icon-yinliangjingyinheix"></use>
                    </svg>
                    <el-slider class="volume" v-model="volume" :vertical="true" >
                    </el-slider>
                </div>
                  <!-- 收藏 -->
                <div class="item" @click="collection">
                    <svg :class="{active:isActive}" class="icon">
                        <use xlink:href="#icon-xihuan-shi"></use>
                    </svg>
                </div>
                    <!-- 下载-->
                <div class="item" @click="download">
                    <svg class="icon">
                        <use xlink:href="#icon-xiazai"></use>
                    </svg>
                </div>
                    <!-- 当前播放列表-->
                <div class="item" @click="changeAside">
                    <svg class="icon">
                        <use xlink:href="#icon-liebiao"></use>
                    </svg>
                </div>

            </div>
        </div>
    </div>
</template>
<script>
import {mapGetters} from "vuex"
import {minx} from "../mixins"
import{download,setCollect,getCollectByUserId} from "../api/index"
export default {
    name:'play-bar',
    data(){return{
        nowTime:'00:00',
        songTime:'00:00',
        curLength:0, //进度条的位置
        progressLength:0, //进度条的总长度
        mouseStartX:0,//鼠标开始拖拽的位置。
        tag:false,//拖拽开始结束标志，当开始拖拽，他的值才会变成true
        volume:50,//音量，默认一半
        toggle:true,//显示隐藏的
    }},
    mixins:[minx],
    mounted(){
    this.progressLength=this.$refs.progress.getBoundingClientRect().width;
    //监听点击音量图标弹出来音量滑块儿
    let volume=document.querySelector(".item-volume")
        volume.addEventListener("click",(e)=>{
         document.querySelector(".volume").classList.add("show-volume")
         e.stopPropagation();
        },false)
        document.querySelector(".volume").addEventListener("click",(e)=>{
            e.stopPropagation();
        },false)
        //点击其他地方，都将滑块儿消失
        document.addEventListener("click",()=>{
            document.querySelector(".volume").classList.remove("show-volume")
        },false)






    },
    computed:{
        ...mapGetters({
             isUrl:"isUrl",
            isPlay:"isPlay",
            playButton:'playButton',
            id:'isId',
            picUrl:'picUrl',
            title:'title',
            artist:'artist',
            duration:'duration',
            curTime:'curTime',
            showAside:'showAside',
            listIndex:'listIndex',
            listOfSongs:"listOfSongs",
            lyric:'lyric',
            autoNext:'autoNext',
            loginIn:'loginIn',
            userId:'userId',
            isActive:'isActive',

            })
    },
    watch:{
        listIndex(){

        },
        volume(){
            this.$store.commit("setVolume",this.volume/100)
        },
        isPlay(){
           if(this.isPlay){
               this.parseLyric(this.lyric)
                this.$store.commit("setPlayButton","#icon-zanting")
            }else{
                this.$store.commit("setPlayButton","#icon-bofang")
            } 
        },
        curTime(){
            this.nowTime=this.formatSecond(this.curTime);
            this.songTime=this.formatSecond(this.duration)
            this.curLength=(this.curTime / this.duration)*100
        },
        autoNext(){
            this.next();//自动播放下一首
        }
    },
    methods:{
        //控制音乐的播放暂停
        togglePlay(){
            if(this.isPlay){
                this.$store.commit("setIsPlay",false)
            }else{
                this.$store.commit("setIsPlay",true)
            }
        },
        //显示播放中的歌曲列表
        changeAside(){
            this.$store.commit("setShowAside",true)
        },
        formatSecond(val){
            let theTime=parseInt(val);
            let result=""
            let hour=parseInt(theTime/3600);
            let minute=parseInt(theTime/60)
            let second=parseInt(theTime%60 )
            if(hour>0){
                if(hour<10){
                    result+='0'+hour+":";
                }else{
                    result+=hour+":";
                }
            } else{
                result+="00:"
            }
            if(minute>0){
                if(minute<10){
                    result+='0'+minute+":";
                }else{
                    result+=minute+":";
                }
            }else{
                result+="00:"
            }
            
            if(second>0){
                if(second<10){
                    result+='0'+second;
                }else{
                    result+=second;
                }
            }else{
                result+="00:"
            }

            return result;
        },
        //开始拖拽
        mousedown(e){
            this.mouseStartX=e.clientX;
            this.tag=true;
},
        //拖拽中
        mousemove(e){
                if(!this.duration){
                    this.tag=false;
                    console.log("超过了")
                    return false;
                }
                // console.log(this.tag,"---")
                if(this.tag){
                    let movementX=e.clientX-this.mouseStartX;//点点移动的距离
                    let curLenth=this.$refs.curProgress.getBoundingClientRect().width;
                    let newPercent=((movementX+curLenth)/this.progressLength)*100
                    if(newPercent>100){
                        newPercent=100;
                    }
                    this.curLength=newPercent;
                    this.mouseStartX=e.clientX
                    this.changeTime(newPercent)
                }
        },
        //拖拽结束
        mouseout(e){
            this.tag=false;
        },
        //点击切换播放进度
        updatemove(e){
            if(!this.tag){
                //进度条的左侧坐标
                let curLenth=this.$refs.bg.offsetLeft;
                let newpercent=((e.clientX-curLenth)/this.progressLength)*100;
                if(newpercent>100){
                    newpercent=100;
                }else if(newpercent<0){
                    newpercent=0;
                }
                this.curLength=newpercent;
                this.changeTime(newpercent)
            }
        },
        //更改歌曲进度
        changeTime(percent){
            let newCur=(percent*0.01)*this.duration;
            this.$store.commit("setChangeTime",newCur)
        },
         replaceLName(str){
      let arr=str.split("-")
      return arr[0]
    },
    //歌名
    replaceFName(str){
      return str.split('-')[1]
    },
     toPlay(url){
         if(url && url!=this.isUrl){
      this.$store.commit("setId",this.listOfSongs[this.listIndex].id);
      this.$store.commit("setUrl",url);
      this.$store.commit("setPicUrl",this.$store.state.configure.HOST +this.listOfSongs[this.listIndex].pic);
      this.$store.commit("setListIndex",this.listIndex);
      this.$store.commit("setTitle",this.replaceFName(this.listOfSongs[this.listIndex].name));
      this.$store.commit("setArtist",this.replaceLName(this.listOfSongs[this.listIndex].name));
      this.$store.commit("setLyric",this.listOfSongs[this.listIndex].lyric);
        console.log("fjdlkasjffffffffffff")
      

         } 
    },
        prev(){//上一首
            if(this.listIndex!=-1 && this.listOfSongs.length>1)  //当前处于不可能的状态或者只有一首音乐的时候不执行
            {
                if(this.listIndex>0){       //不是第一首音乐
                    this.$store.commit("setListIndex",this.listIndex-1);//直接返回上一首
                }else{  //如果是第一首音乐
                //listIndex默认是null，直接执行这个，则最初状态点击pre，则会播放最后一首，那么listIndex就一切正常了
                    this.$store.commit("setListIndex",this.listOfSongs.length-1);//直接返回上一首
                }
                let url=this.listOfSongs[this.listIndex].url
                    this.toPlay(url);//
            }
        },
        next(){
            //下一首
            if(this.listIndex!=-1 && this.listOfSongs.length>1)  //当前处于不可能的状态或者只有一首音乐的时候不执行
            {
                if(this.listIndex<this.listOfSongs.length-1){       //不是最后一首音乐
                    this.$store.commit("setListIndex",this.listIndex+1);//直接返回下一首
                }else{  //如果是第一首音乐
                    this.$store.commit("setListIndex",0);//直接返回第一首
                }
                let url=this.listOfSongs[this.listIndex].url
                    this.toPlay(url);//
            }
        },
        toLyric(){
            this.$router.push({path:"/lyric"})
        },
        // 下载音乐
        download(){
            download(this.$store.state.configure.HOST+this.isUrl).then(res=>{
                let content=res;//直接接收数据流
                let link=document.createElement("a")//创建一个a连接
                link.download=`${this.artist}-${this.title}.mp3`;//下载的文件名
                link.style.display='none';
                //将字符转为blob对象
                let blob=new Blob([content])
                link.href=URL.createObjectURL(blob);
                //把链接地址加到document里
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link)
            })
        },
        //收藏
        collection(){
            if(this.loginIn){
                this.$store.commit("setIsActive",true)
                let params=new URLSearchParams();
                params.append("userId",this.userId)
                params.append("type",0)
                params.append("songId",this.id)
                setCollect(params).then(res=>{
                    if(res.code===1){
                        this.$message.success("收藏成功!")
                    }else if(res.code===2){
                        this.$message.error("已经收藏过了!")
                    }
                })
            }else{
                this.$message.error("请先登录哦!")
            }
        },
    }
}
</script>
<style lang="scss" scoped>
@import "../assets/css/play-bar.scss";

</style>