<template>
   <div class="song-audio" style="position:absolute;bottom:10px">
        <audio :src="$store.state.configure.HOST+isUrl" ref="player"
        autoplay="false"
        controls="controls"
        preload="true"
        @canplay="startPlay"
        @ended="ended"
        @timeupdate="timeupdate"
        ></audio>       
    </div> 
</template>
<script>
import {mapGetters} from "vuex"

export default {
    data(){return{
    }},
    mounted(){
    },
    watch:{
        isPlay(val){
                this.togglePlay();
        },
        //跳转至某个指定时刻
        changeTime(){
        this.$refs.player.currentTime=this.changeTime;
        },
        volume(val){
            this.$refs.player.volume=val;
        }
    },
    updated(){
    },
    computed:{
        ...mapGetters({
            isUrl:"isUrl",
            isPlay:"isPlay",
            duration:'duration',
            listOfSongs:'listOfSongs',
            id:'isId',
        curTime:'curTime',//当前音乐播放的位置
        changeTime:'changeTime', //指定播放时刻,
        title:'title', //歌名
        artist:'artist', //歌手名，
        picUrl:'picUrl', //歌曲图片,
        autoNext:'autoNext', //自动播放下一首，
        lyric:'lyric',  //未被处理的歌词信息，
        tempList:'tempList',  //单个歌单信息
        listIndex:'listIndex',   //当前个歌单在歌曲中的位置。
        volume:'volume',
        }),
    },
    methods:{
        //获取连接后准备播放
        startPlay(){
            let player=this.$refs.player;
            this.$store.commit("setDuration",player.duration)
//开始播放
            player.play();
            this.$store.commit("setIsPlay",true)

        },
        ended(){
            //播放完之后
            this.$store.commit('setIsPlay',false)
            this.$store.commit('setCurTime',0)
            this.$store.commit('setAutoNext',!this.autoNext)
            
        },
        //开始暂停
        togglePlay(){
            let player=this.$refs.player
            if(this.isPlay){
                player.play();
            }else{
                player.pause();
            }
        },
        //音乐播放的时候记录音乐播放的位置放入缓存。
        timeupdate(){
                this.$store.commit('setCurTime',this.$refs.player.currentTime)
        }
    
    },
    
}
</script>
<style scoped>
    .song-audio{
        display: none;
        
    }
</style>