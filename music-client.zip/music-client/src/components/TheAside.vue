<template>
<transition name="slide-fade">
        <div class="the-aside" v-if="showAside">
               <h2 class="title">播放列表</h2>
                <ul class="menus">
                    <li v-for="(item,index) in listOfSongs" :key="index" :class="{'is-play':isId==item.id}"
                    @click="toPlay(item.id,item.url,item.pic,item.index,item.name,item.lyric)">{{item.name}}</li>
                </ul>
        </div>
</transition>
</template>
<script>
import {mapGetters} from "vuex"
import{minx} from "../mixins/index"
export default {
    name:"the-aside",
  mounted(){
      let that=this;
        document.addEventListener('click',()=>{
                that.$store.commit("setShowAside",false)
        },true)
  },
  created(){
  },
    computed:{
        ...mapGetters([
            'showAside',
            'listOfSongs',
            'isId',
        ])
    },
    methods:{
  //获取名字前半部分-歌手名
    replaceLName(str){
      let arr=str.split("-")
      return arr[0]
    },
    //歌名
    replaceFName(str){
      return str.split('-')[1]
    },
        toPlay(id,url,pic,index,name,lyric)
        {
      this.$store.commit("setId",id);
      this.$store.commit("setUrl",url);
      this.$store.commit("setPicUrl",this.$store.state.configure.HOST +pic);
      this.$store.commit("setListIndex",index);
      this.$store.commit("setTitle",this.replaceFName(name));
      this.$store.commit("setArtist",this.replaceLName(name));
      this.$store.commit("setLyric",this.parseLyric(lyric));

    }

    }
    
}
</script>
<style lang="scss" scoped>
@import "../assets/css/the-aside.scss";
</style>