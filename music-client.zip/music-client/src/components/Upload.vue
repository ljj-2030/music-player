<template>
    <div class="upload">
        <p class="title">修改头像</p>
        <hr/>
        <div class="section">
            <el-upload drag="" :action="uploadUrl()" :show-file-list="false"
            :on-success="handleSuccess"  :before-upload="before">
            <i class="el-icon-upload"></i>
            <div>将文件拖到此处，或 <span style="color:blue">修改头像</span></div>
            <div slot="tip">只能上传jpg文件，且文件大小不能超过10mb</div>
            </el-upload>
        </div>
    </div>
</template>
<script>
import{mapGetters} from "vuex"
import{minx} from "../mixins"
export default {
    name:'Upload',
    mixins:[minx],
    computed:{
        ...mapGetters([
                'userId',
        ])
    },
    data(){
        return{
               
        }
    },
    methods:{
        handleSuccess(res,file){
            if(res.code===1){
                this.$message.success("上传成功!")
                this.$store.commit("setAvator",res.avator)
            }else{
                this.$message.error("上传失败!")
            }

        },
         uploadUrl(){
                    return `${this.$store.state.configure.HOST}/consumer/updateConsumerPic?id=${this.userId}`
                },
        before(file){
            const isJPG=file.type==='image/jpeg';
            const isLt10=(file.size/1024/1024)  <10;
            if(!isJPG){
                this.$message.error("上传图片只能是jpg格式")
                return false;
            }
            if(!isLt10){
                this.$message.error("上传图片只能小于10mb")
                return false;
            }
        },
            }
}
</script>
<style lang="scss" scoped>
@import"../assets/css/upload.scss";
</style>