<template>
    <div class="the-header">
        <div class="header-logo">
            <svg class="icon">
                <use xlink:href="#icon-erji"></use>
            </svg>
            <span @click.prevent="goPage('首页','/')">music</span>
            <ul class="navbar">
                <li :class="{active:item.name==activeName}" v-for="(item) in navMsg" :key="item.path" @click="goPage(item.name,item.path)">
                  {{item.name}}
                </li>
                <li>
                    <div class="header-search">
                        <input type="text" placeholder="搜索音乐" @keyup.enter="goSearch()" v-model="keywords">
                        <div class="search-btn" @click="goSearch()">
                            <svg class="icon">
                                <use xlink:href="#icon-sousuo"></use>
                            </svg>
                        </div>
                    </div>
                </li>
                <li @click="goPage(item.name,item.path)" v-show="!loginIn" :class="{active:item.name===activeName}" v-for="(item) in loginMsg" :key="item.path">
                    {{item.name}}
                </li>
            </ul>
        </div>
        <div class="header-right" v-show="loginIn">
                <div id="user">
                    <img :src="attachImgUrl(avator)" alt="">
                </div>
                <ul class="menu"> 
                    <li v-for="(item) in menulist" :key="item.path" @click="goMenu(item.path)">{{item.name}}</li>

                </ul>
            </div>

    </div>
</template>
<script>
import {navMsg,loginMsg,menulist} from "../assets/data/header"

import{mapGetters} from "vuex"
export default {
    created(){
    this.navMsg=navMsg
    this.loginMsg=loginMsg
    this.menulist=menulist;
    },
    name:"theHeader",
    data(){return{
        navMsg:[],//左侧导航栏
        loginMsg:[],//右侧导航栏
        keywords:'',
        menulist:[],
       
    }},
    
    computed:{
        ...mapGetters([
            'activeName',
            'listIndex',
            'loginIn',
            'avator',
        ])
    },
    mounted(){
            document.querySelector("#user").addEventListener("click",(e)=>{
                    document.querySelector(".menu").classList.add("show")
                    e.stopPropagation;
            },false)
                    document.querySelector(".menu").addEventListener("click",(e)=>{
                            e.stopPropagation;
                    })
            document.addEventListener("click",(e)=>{
                    document.querySelector(".menu").classList.remove(("show"))
                    e.stopPropagation;
            },true)
    },
    methods:{
        goPage(name,path){
            if(!this.loginIn && path==='/my-music'){
                this.$message.error("请先登录才能查看到!")
            }else{
                this.$store.commit('setActiveName',name);
                this.$router.push({
                    path:path,
                })
            }
        },
        goMenu(path){
            if(path===0){
                //退出
                this.$store.commit("setLoginIn",false)
                this.$router.go(0) //刷新页面
                this.$store.commit("setIsActive",false)
            }else{
                this.$router.replace(path)
            }
            
        },
        goSearch(){
            //转到搜索页面
            this.$store.commit("setKeywords",this.keywords)
            console.log(this.keywords,"+++++++")
            this.$router.push({path:"/search",query:{keywords:this.keywords}})
        },
         attachImgUrl(path){
      return  this.$store.state.configure.HOST+path || "../assets/img/user.jpg"
    },
    }
}
</script>

<style lang="scss" scope>
@import "../assets/css/the-header.scss";
.swiper img[data-v-07a952a8]{
    width: 100%;
    margin-top: 30px;
}
</style>