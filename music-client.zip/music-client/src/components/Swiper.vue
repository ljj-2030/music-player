<template>
<div class="swiper">
    <el-carousel :interval="4000" type="card" height="280px">
        <el-carousel-item v-for="(item,index) in swiperList" :key="index">
            <img :src="item.picImg" alt="" />
        </el-carousel-item>
    </el-carousel>
</div>
</template>
<script>
//获取轮播图数据
import {swiperList} from "@/assets/data/swiper"
export default {

    created(){
        this.swiperList=swiperList;

    },
    name:"swiper",
    data(){return{
  //轮播图列表
      swiperList:[],
    }}
}
</script>
<style lang="scss" scoped>
@import "../assets/css/swiper.scss";
</style>