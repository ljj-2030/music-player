<template>
<div>
        <div class="info">
                <div class="title">
                    <span>编辑个人资料</span>
                </div>
            <el-form :model="registerForm" ref="registerForm" label-width="70px" class="demo-ruleForm" :rules="rules">
                    <el-form-item prop="username" label="用户名">
                        <el-input v-model="registerForm.username" placeholder="用户名"/>
                    </el-form-item>
                     <el-form-item prop="password" label="密码">
                        <el-input v-model="registerForm.password" type="password" placeholder="密码"/>
                    </el-form-item>
                     <el-form-item prop="sex" label="性别">
                        <el-radio-group v-model="registerForm.sex">
                            <el-radio :label="0">女</el-radio>
                            <el-radio :label="1">男</el-radio>
                        </el-radio-group>
                    </el-form-item>
                     <el-form-item prop="phoneNum" label="手机号">
                        <el-input v-model="registerForm.phoneNum" placeholder="手机号"/>
                    </el-form-item>
                     <el-form-item prop="email" label="电子邮件">
                        <el-input v-model="registerForm.email" placeholder="电子邮件"/>
                    </el-form-item>
                     <el-form-item prop="birth" label="生日">
                        <el-date-picker v-model="registerForm.birth" placeholder="选择日期">
                        </el-date-picker>
                    </el-form-item>
                     <el-form-item prop="introduction" label="签名">
                        <el-input v-model="registerForm.introduction" placeholder="签名" type="textarea"/>
                    </el-form-item>
                     <el-form-item prop="location" label="地区">
                        <el-select v-model="registerForm.location" placeholder="地区" style="width:100%">
                            <el-option v-for="item in cities" :key="item.value" :label="item.label" :value="item.value"></el-option>
                        </el-select>
                    </el-form-item>
            </el-form>   
             <div class="login-btn">
                        <el-button @click="goPage()">取消</el-button>
                        <el-button type="primary" @click="saveMsg">确定</el-button>
                    </div>
        </div>
</div>
</template>
<script>
import LoginLogo from '../components/loginLogo.vue'
import{rules,cities} from "../assets/data/form"
import{updateUser,getUser} from "../api/index"
import{mapGetters} from "vuex"
export default {
    components:{
        LoginLogo,
    },
    created(){
        this.rules=rules;
        this.cities=cities;
    },
    mounted(){
            this.getMsg(this.userId)
    },
    computed:{
        ...mapGetters([
            'userId'
        ])
    }
    ,
    data(){return{
        registerForm:{
            username:'',//用户名
            password:'',//密码
            sex:'',//性别
            phoneNum:'',//电话号码
            email:'',//电子邮件
            birth:'',//生日
            introduction:'',//签名
            location:'',//地区
        },
        cities:[],//所有地区---省/市
        rules:[]
    }},
    methods:{
        
        getMsg(userId){
            getUser(userId).then(res=>{
                this.registerForm.username=res.username;
                this.registerForm.password=res.password;
                this.registerForm.sex=res.sex;
                this.registerForm.phoneNum=res.phoneNum;
                this.registerForm.email=res.email;
                this.registerForm.birth=res.birth;
                this.registerForm.introduction=res.introduction;
                this.registerForm.location=res.location;
            })
        },
        saveMsg(){
            let form=new FormData();
            form.append("username",this.registerForm.username);
            form.append("password",this.registerForm.password);
            form.append("sex",this.registerForm.sex);
            form.append("phoneNum",this.registerForm.phoneNum);
            form.append("email",this.registerForm.email);
            let birth=this.registerForm.birth
            if(typeof birth==='string')
                birth=birth.substring(0,4)+"-"+birth.substr(5,2)+"-"+birth.substr(8,2)
            else
                birth=birth.getFullYear()+"-"+(birth.getMonth()>=10?birth.getMonth():'0'+birth.getMonth())+"-"+(birth.getDate()>=10?birth.getDate():'0'+birth.getDate())

            form.append("birth",birth);
            form.append("introduction",this.registerForm.introduction);
            form.append("location",this.registerForm.location);
            form.append("id",this.userId)
            updateUser(form).then(res=>{
                if(res===true){
                    this.$message.success("更改成功,请重新登录，获取最新数据")
                    this.getMsg(this.userId)
                }else{
                    this.$message.error("更新失败！")
                }
            })        
        },
        goPage(){
            this.$router.go(-1)
        }
    }
}
</script>




<style lang="scss" scoped>
@import"../assets/css/info.scss";
</style>