<template>
  <div id="app">
    <song-audio/>
    <the-aside/>
    <the-header></the-header>
    <router-view class="music-content"/>
    <to-top/>
    <play-bar />
    <the-footer/>
      </div>
</template>

<script>
import theHeader from "./components/TheHeader.vue"
import toTop from "./components/ScollTop.vue"
import TheFooter from "./components/TheFooter.vue"
import SongAudio from './components/SongAudio.vue'
import PlayBar from './components/PlayBar.vue'
import TheAside from './components/TheAside.vue'
export default {
  name: 'App',
  components:{
    theHeader,
    toTop,
    TheFooter,
    SongAudio,
    PlayBar,
    TheAside,
  }
  
}
</script>

<style  lang="scss" scoped>
@import './assets/css/app.scss';
</style>
