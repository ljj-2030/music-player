const styleList=[
{name:"全部歌单"},
{name:"华语"},
{name:"粤语"},
{name:"欧美"},
{name:"日韩"},
{name:"轻音乐"},
{name:"BGM"},
{name:"乐器"},

]
export {
    styleList,
}