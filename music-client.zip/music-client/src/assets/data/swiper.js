//轮播图数据
const swiperList=[
    {picImg: require("../img/swiper/1.jpg")},
    {picImg: require("../img/swiper/2.jpg")},
    {picImg: require("../img/swiper/3.jpg")},
    {picImg: require("../img/swiper/4.jpg")},
    {picImg: require("../img/swiper/5.jpg")},
    {picImg: require("../img/swiper/6.jpg")},
    {picImg: require("../img/swiper/7.jpg")},
    {picImg: require("../img/swiper/8.jpg")},
    
]
export{
    swiperList
}