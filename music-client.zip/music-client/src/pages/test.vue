<template>
    <div class="test" style="margin-top:500px;">这是一个测试组件</div>
</template>