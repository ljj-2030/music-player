<template>
    <div class="search" style="margin-top:100px;">
        <nav class="searchList-nav" ref="change">
            <span :class="{isActive:toggole=='/search'}" @click="handleChange('/search')">歌曲</span>
            <span :class="{isActive:toggole=='/search/searchSongList'}" @click="handleChange('/search/searchSongList')">歌单</span>
        </nav>
    <!--子路由-->
    <router-view/>
    </div>
</template>
<script>
export default {

    created(){
        this.toggole=(this.$route.path)
    },
    data(){return{
        toggole:'/search',
    }},
    methods:{
        handleChange(path){
            this.toggole=path;
            this.$router.replace(path)
        }
    }
}
</script>
<style lang="scss"  scoped>
@import "../assets/css/search.scss";

</style>