<template>
     <div class="singer">
         <ul class="singer-header">
             <li :class="{active:item.name===activeName}" v-for="(item,index) in singerStyle" :key="index" @click="handleChangeView(item)">
                 {{item.name}}
             </li>
         </ul>
         <div>
        <content-list :contentList="data">
        </content-list>
        <div class="pagination">
            <el-pagination @current-change="handleCurrentChange" background layout="total,prev,pager,next"
            :current-page="currentPage" :page-size="pageSize" :total="albumDatas.length"></el-pagination>
        </div>
        </div>
    </div>
</template>
<script>
import ContentList from "../components/ContentList.vue"
import{minx} from "../mixins/index"
import{getAllSinger,getSingerOfSex, setRank} from "../api/index"
import{singerList} from "../assets/data/singer"
export default {
    created(){
        this.getAllSinger()
        this.singerStyle=singerList;
    },
    mixins:[minx],
    components:{
        ContentList,
    },
    data(){return{
        albumDatas:[],
        pageSize:15,//默认一页15
        currentPage:1,//默认第一页
        singerStyle:[],//歌单风格
        activeName:"全部歌手"
    }},
    computed:{
        data(){ //计算应该显示的数据
            return this.albumDatas.slice((this.currentPage-1)*this.pageSize,this.currentPage*this.pageSize)
        }
    },
    methods:{
        getAllSinger(){
           getAllSinger().then(res=>{
               this.albumDatas=res;
           })
        },
        //获取当前页
        handleCurrentChange(val){
            this.currentPage=val;
        },
        //根据style显示对应的歌单
        handleChangeView(item){
                this.albumDatas=[]
                //判断使用那些风格进行显示
                if(item.name==='全部歌手')
                    this.getAllSinger();
                else
                    this.activeName=item.name;
                    this.goSingerOfSex(item.type);
        },
        //根据性别查询对应的歌手
        goSingerOfSex(sex){
           getSingerOfSex(sex).then(res=>{
               this.albumDatas=res;
           })
        }
    }
    
}
</script>
<style lang="scss" scoped>
    @import"../assets/css/singer.scss";
</style>