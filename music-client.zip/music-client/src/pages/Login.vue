<template>
<div>
        <login-logo/>
        <div class="signUp">
                <div class="signUp-head">
                    <span>用户登录</span>
                </div>
            <el-form :model="registerForm" ref="registerForm" label-width="70px" class="demo-ruleForm" :rules="rules">
                    <el-form-item prop="username" label="用户名">
                        <el-input v-model="registerForm.username" placeholder="用户名"/>
                    </el-form-item>
                     <el-form-item prop="password" label="密码">
                        <el-input v-model="registerForm.password" type="password" placeholder="密码"/>
                    </el-form-item>
                     
                    <div class="login-btn">
                        <el-button @click="goPage()">注册</el-button>
                        <el-button type="primary" @click="SignUp">确定</el-button>
                    </div>
            </el-form>   
        </div>
</div>
</template>
<script>
import LoginLogo from '../components/loginLogo.vue'
import{rules,cities} from "../assets/data/form"
import{verify} from "../api/index"
export default {
    components:{
        LoginLogo,
    },
    created(){
        this.rules=rules;
        this.cities=cities;
    },
    mounted(){
            this.changeIndex("登录")
    },
    data(){return{
        registerForm:{
            username:'',//用户名
            password:'',//密码
           
        },
        cities:[],//所有地区---省/市
        rules:[]
    }},
    methods:{
        SignUp(){
            let form=new FormData();
            form.append("username",this.registerForm.username)
            form.append("password",this.registerForm.password)
            verify(form).then(res=>{
                if(res.code===0){
                    this.$message.error(res.msg)
                }else{
                    this.$message.success(res.msg)
                    this.$store.commit("setLoginIn",true)
                    this.$store.commit("setUserId",res.userId);
                    this.$store.commit("setAvator",res.avator);
                    this.changeIndex("首页")
                    this.$router.replace("/")
                }
            })

        },
        goPage(){
            this.$router.replace("/sign-up")
        },
        changeIndex(val){
            this.$store.commit("setActiveName",val)
        }
    }
}
</script>




<style lang="scss" scoped>
@import"../assets/css/sign-up.scss";
</style>