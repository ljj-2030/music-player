<template>
  <div class="home">
    <swiper/>
    <div class="section" v-for="(item,index) in songList" :key="index">
          <div class="section-title">{{item.name}}</div>
          <content-list :contentList="item.list"></content-list>
    </div>
  </div>
</template>
<script>
import Swiper from "../components/Swiper.vue"
import{getAllSinger,getAllSongList} from "../api/index"
import ContentList from '../components/ContentList.vue'
export default {
  created(){
    this.getSongList();
  },
  components:{
      ContentList,
  },
  data(){return{
   songList:[
            {name:'歌单',list:[]},
            {name:'歌手',list:[]},
        ]
  }},
  methods:{
 getSongList(){
            getAllSongList().then(r=>{
                this.songList[0].list=r.slice(0,10);
            })
            getAllSinger().then(r=>{
                this.songList[1].list=r.slice(0,10);
            })
        }
  },
  components:{
    Swiper,
    ContentList,
  }

}
</script>
<style lang="scss" scoped>
@import '../assets/css/home.scss'

</style>
