<template>
    <div class="song-lyric">
        <h1 class="lyric-title">歌词</h1>
        <!-- 有个词 -->
        <ul class="has-lyric" v-if="lyr.length">
            <li v-for="(item,index) in lyr" :key="index">
                {{item[1].replace("]",'')}}
            </li>
        </ul>
    </div>
</template>
<script>
import{mapGetters} from "vuex"
import {minx} from "../mixins/index"
export default {
    computed:{
        ...mapGetters([
            'curTime',
            'id',
            'lyric',
            'listIndex',
            'listOfSongs'
        ])
    },
    created(){
        this.lyr=this.parseLyric(this.lyric).filter((data)=>{
                return data[0]!=null;
        })
        
    },
    data(){return{
        lyr:[] ,//当前歌曲的歌词
    }},
    mixins:[minx]
}
</script>
<style lang="scss" scoped>
@import "../assets/css/lyric.scss";

</style>