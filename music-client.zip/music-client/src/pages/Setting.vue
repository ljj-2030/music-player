<template>
    <div class="setting">
        <div class="leftCol">
            <div class="settingMainHeader">设置</div>
            <ul class="setting-aside">
                <li :class="{activeColor:activeName==item.name}"
                    @click="handleClick(item)"
                 v-for="(item,id) in settingList" :key="id">
                        {{item.name}}
                </li>
            </ul>
        </div>
        <div class="contentCol">
            <component :is="compStr"></component>
        </div>
    </div>
</template>

<script>
import Info from "../components/Info.vue"
import Upload from "../components/Upload.vue"
export default {
    components:{
            Info,
            Upload,
    },
    data(){return{
        settingList:[
            {name:"个人信息",path:'info'},
            {name:"修改头像",path:'upload'},
        ],
        activeName:'个人信息',
        compStr:'Info',
    }},
    methods:{
        handleClick(item){
            this.activeName=item.name
            this.compStr=item.path;
        }
    }
}
</script>

<style lang="scss" scope>
@import "../assets/css/setting.scss";

</style>