<template>
    <div class="singer-album">
        <div class="album-slide">
            <div class="singer-img">
                <img :src="attachImgUrl(singer.pic)" alt="">
            </div>
            <ul class="info">
                <li v-if="singer.sex===0 || singer.sex===1">{{attachSex(singer.sex)}}</li>
                <li>生日:{{attachBirth(singer.birth)}}</li>
                <li>故乡:{{singer.location}}</li>
            </ul>
        </div>
        <div class="album-content">
            <div class="intro">
                <h2>{{singer.name}}</h2>
                <span>{{singer.introduction}}</span>
            </div>
            <div class="content">
            <album :songList="listOfSongs">
                <template #title>歌手</template>
            </album>
            <comment :playId="singerId" :type="0"></comment>
</div>
        </div>
    </div>
</template>
<script>
import {minx} from "../mixins/index"
import{getAllSongOfSinger,getSingerBySingerId} from "../api/index"
import {mapGetters} from "vuex"
import Album from "../components/Album.vue"
import Comment from "../components/Comment.vue"
export default {
    mixins:[minx],
    data(){
          return{
              singerId:'',
              singer:{},

        }
    },
    created(){
            this.singerId=this.$route.params.id
            // // this.singer=this.tempList
            this.getSingerOfId();
            this.getAllSongOfSingerId();
    },
    computed:{
        ...mapGetters([
            'listOfSongs',
            'tempList',
            'loginIn',
            'userId',
        ])
    },methods:{
        //根据歌手id查询所有的歌曲
        getAllSongOfSingerId(){
            getAllSongOfSinger(this.singerId).then(res=>{
                    this.$store.commit("setListOfName",res)
            })
        },
        //根据歌手id获取歌手对象
        getSingerOfId(){
            getSingerBySingerId(this.singerId).then(res=>{
                this.singer=res;
            })
        },
        //获取性别
        attachSex(value){
            if(value===0)
                return '男'
            if(value===1)
                return '女'
            return ''
        }
    },
    components:{
        Album,
        Comment,
    }
    
}
</script>

<style lang="scss" scoped>
@import"../assets/css/singer-album.scss";

</style>