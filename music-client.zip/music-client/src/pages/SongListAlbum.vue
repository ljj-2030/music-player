<template>
    <div class="song-list-album">
        <div class="album-slide">
            <div class="album img">
                <img :src="attachImgUrl(tempList.pic)" alt=""/> 
            </div>
            <div class="album-info">
                <h2>简介</h2>
                <span>{{tempList.introduction}}</span>
            </div>>
        </div>
        <div class="album-content">
            <div class="album-title">
                <p>{{tempList.title}}</p>
            </div>
            <div class="album-score">
                <h3>歌单评分:</h3>
                <div>
                    <el-rate v-model="average" disabled></el-rate>
                </div>
                <span>{{average*2}}</span>

                 <div class="album-score">
                <h3>评价:</h3>
                <div @click="setRank">
                    <el-rate v-model="rank" allow-half show-text></el-rate>
                </div>
                </div>
            </div>
             <div class="songs-body">
    <album :songList="listOfSongs">
        <template #title>歌单</template>
    </album>
    <comment :playId="songListId" :type="1"></comment>
</div>
        </div>
       
    </div>

</template>

<script>
import {minx} from "../mixins/index"
import {mapGetters} from "vuex"
import {getAllSongOfSinger,getRankSongOfId,setRank} from "../api/index"
import Album from "../components/Album.vue"
import Comment from "../components/Comment.vue"
export default {
    data(){
        return{
            songlist:[],
            songListId:'',
            average:0,//平均分
            rank:0,//提交评价的分数


        }       
    },
    created(){
           this.songListId=(this.$route.params.id)

            this.getSongId();
            this.getRank(this.songListId)

    },
    components:{
        Album,
        Comment,
    },
    methods:{
            //获取当前歌单的歌曲列表根据歌手id
            getSongId(){
                getAllSongOfSinger(this.songListId).then(res=>{
                    this.songlist.push(...res)
                })
                this.$store.commit("setListOfName",this.songlist)
            },
            //获取歌单评分
            getRank(id){
                    getRankSongOfId(id).then(res=>{
                             if(res==='NaN'){
                                 this.average=0
                             }else{
                                 this.average=res/2;
                             }
                            })
            },
            //提交评分，必须先确保登录
            setRank(){
                    if(this.loginIn){
                        let params=new URLSearchParams()
                        console.log(this.userId,'---')
                        params.append("songListId",this.songListId)
                        params.append("consumerId",this.userId)
                        params.append('score',this.rank*2)
                       
                       setRank(params).then(res=>{
                               if(res===true){
                                   this.$message.success("评价成功!")
                                   this.getRank(this.songListId);
                               }else{
                                   this.$message.error("评价失败!")
                               }
                        }).catch(res=>{
                            this.$message.error("评价失败！已经评价过了")
                        })
                    }else{
                        this.$message.error("请先去登录吧!")
                    }
            }

    },
    mixins:[minx],
    computed:{
        ...mapGetters([
            'listOfSongs',//当前播放列表
            'tempList',//当前歌曲对象      
            'loginIn',  
            'userId',
        ])
    }
    
}
</script>

<style lang="scss" scoped>
@import"../assets/css/song-list-album.scss";

</style>