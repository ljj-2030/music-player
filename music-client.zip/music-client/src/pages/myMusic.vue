<template>
    <div class="my-music"  >
            <div class="album-slide">
                  <div class="album-img">
                        <img :src="attachImgUrl(avator)">
                  </div>
                  <ul class="album-info">
                      <li>昵称: {{username}}</li>
                      <li>性别: {{userSex}}</li>
                      <li>生日: {{birth}}</li>
                      <li>地区: {{location}}</li>
                  </ul>
            </div>
            <div class="album-content">
                <div class="album-title">
                    个性签名:{{introduction}}
                </div>
                <div class="song-body">
                    <album :songList="collectList">
                         <template #title>我的收藏</template>
                     </album>
                </div>
            </div>
    </div>
</template>
<script>
import{minx} from "../mixins"
import{mapGetters} from "vuex"
import Album from "../components/Album.vue"
import{getUser,getCollectByUserId,getSongBySongId} from "../api"
export default {
    mixins:[minx],
    mounted(){
        this.getMsg(this.userId)
        this.getCollection(this.userId)
    },
    data(){return{
        avator:'',//头像
        username:'',//用户名
        userSex:'',//性别
        birth:'',
        location:'',
        introduction:'',
        collection:[],//收藏的歌曲列表
        collectList:[],//收藏的歌曲列表(带歌曲详情)
    }},
    components:{
        Album,
    },
    computed:{
        ...mapGetters([
            'listOfSongs',//当前播放列表
            'userId',
        ])
    },
    methods:{
        
        getMsg(userId){
            getUser(userId).then(res=>{
                this.username=res.username;
                this.avator=res.avator;
                if(res.sex===1){
                    this.userSex="男"
                }else if(res.sex===0){
                    this.userSex='女'
                }
                this.birth=this.attachBirth(res.birth)
                this.location=res.location
                this.introduction=res.introduction;
            })
        },
        //获取收藏列表
        getCollection(userId){
            getCollectByUserId(userId).then(res=>{
                    this.collection=res;
                    for(let collect of this.collection){
                        this.getSongById(collect.songId)
                    }
                })
        },
        //通过歌曲id获取歌曲信息
        getSongById(songId){
            getSongBySongId(songId).then(res=>{
                    this.collectList.push(res)
            })
        }
    }

}
</script>
<style lang="scss" scoped>
@import"../assets/css/my-music.scss";
</style>