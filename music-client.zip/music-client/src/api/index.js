/* eslint-disable*/
import { get, update,post, deleted } from './http'
import Axios from 'axios'
//获取所有歌手
export const getAllSinger=()=>{
    return get("/singer/getAllSinger",{})
}

//根据性别查询歌手
export const getSingerOfSex=(sex)=>{
    return get("/singer/singerOfSex?sex="+sex)
}


//根据歌手id获取歌手对象
export const getSingerBySingerId=(id)=>{
    return get("/singer/selectByKey?id="+id)
}

//########################歌曲相关

export const getAllSong=()=>{
    return get("/song/getAllSong");
}
//根据歌手id查找歌曲
export const getAllSongOfSinger=(singerId)=>{
    return get("/song/getSongOfSinger",{params:{singerId:singerId}})
}
//根据歌曲id查找歌曲
export const getSongBySongId=(songId)=>{
    return get("/song/getSong?songId="+songId)
}

//根据歌名模糊查询歌曲
export const getSongOfName=(name)=>{
    return get("/song/getSongOfName",{params:{name:name}})
}

//根据搜索模糊查询歌单
export const songListLikeTitle=(title)=>{
    return get("/songList/songListOfTitle?title="+title)
}
//根据风格模糊查询歌单
export const songListLikeStyle=(style)=>{
    return get("/songList/songListOfStyle?style="+style)
}



//#####################歌单相关

export const getAllSongList=()=>{
    return get("/songList/getAllSongList")
}
//################################用户管理相关

export const getAllConsumer=()=>{
    return get("/consumer/getAllConsumer")
}
//添加用户
export const addConsumer=(data)=>{
    return post("/consumer/add",data)

}
//验证用户
export const verify=(data)=>{
    return post("/consumer/login",data)
}
//根据userId获取用户
export const getUser=(id)=>{
    return get("/consumer/getUser?userId="+id)
}
//编辑用户
export const updateUser=(data)=>{
    return update("/consumer/update",data)
}


//下载音乐
export const download=(url)=>Axios({

    method:"get",
    url:url,
    responseType:'blob'
})



//=============评价
//新增评分
export const setRank=(data)=>post('/rank/add',data);
//获取指定歌单的评分
export const getRankSongOfId=(songListId)=>get("/rank/avg?songListId="+songListId)

//添加评论
export const setComment=(data)=>post("/comment/add",data)
//获取当前歌单的所有评论
export const commentOfSongListId=(songListId)=>get("/comment/commentOfSongListId?songListId="+songListId)
//获取当前歌曲的所有评论
export const commentOfSongId=(songId)=>get("/comment/commentOfSongId?songId="+songId)
//点赞
export const setLike=(data)=>{return post("/comment/like",data)}


//###########收藏##################
// 新增收藏
export const setCollect=(data)=>{
    return post("/collect/add",data);
}
//用户的收藏列表
export const getCollectByUserId=(id)=>{
    return get("/collect/collectOfUserId?userId="+id);
}

