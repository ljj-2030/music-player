const song={
        
        state:{
        listOfSongs:[],//当前歌曲列表
        url:'',
        id:'',
        isPlay:false,
        playButton:'#icon-bofang',
        duration:0,//音乐时长,
        curTime:0,//当前音乐播放的位置
        changeTime:0, //指定播放时刻,
        title:'', //歌名
        artist:'', //歌手名，
        picUrl:'', //歌曲图片,
        autoNext:true, //自动播放下一首，
        lyric:[],  //未被处理的歌词信息，
        tempList:{},  //单个歌单信息
        listIndex:null,   //当前个歌单在歌曲中的位置。
        volume:50,      //音量。
        keywords:'',//搜索歌曲歌单的关键字
        },
        mutations:{
          setKeywords(state,keywords){
            window.sessionStorage.setItem('keywords',JSON.stringify(keywords))
            state.keywords=keywords
          },
          setListOfName(state,name){
                window.sessionStorage.setItem('listOfSongs',JSON.stringify(name))
                state.listOfSongs=name;
          },
          setIsPlay(state,isPlay){
              state.isPlay=isPlay;
              window.sessionStorage.setItem("isplay",JSON.stringify(isPlay));
          },
          setUrl(state,url){
            state.url=url;
          },
          setId(state,id){
            state.id=id;
          },
          setPlayButton(state,ply){
            state.playButton=ply;
            window.sessionStorage.setItem("playButton",JSON.stringify(ply));
          },
          setDuration(state,time){
              state.duration=time;
            window.sessionStorage.setItem("duration",JSON.stringify(time));
          },
          setCurTime(state,time){
            state.curTime=time;
            window.sessionStorage.setItem("curTime",JSON.stringify(time));
          },
          setChangeTime(state,time){
            state.changeTime=time;
            window.sessionStorage.setItem("changeTime",JSON.stringify(time));
          },
          setTitle(state,title){
            state.title=title;
            window.sessionStorage.setItem("title",JSON.stringify(title));
          },
          setArtist(state,name){
            state.artist=name;
            window.sessionStorage.setItem("artist",JSON.stringify(name));
          },
          setPicUrl(state,picUrl){
            state.picUrl=picUrl
            window.sessionStorage.setItem("picUrl",JSON.stringify(picUrl));
          },
          setAutoNext(state,auto){
                state.autoNext=auto;
            window.sessionStorage.setItem("autoNext",JSON.stringify(auto));
          } ,
          setLyric(state,lyric){
            state.lyric=lyric;
            window.sessionStorage.setItem("lyric",JSON.stringify(lyric));
          },  //未被处理的歌词信息，
          setTempList(state,templist){
            state.tempList=templist;
            window.sessionStorage.setItem("tempList",JSON.stringify(templist));
          },
          setListIndex(state,index){
              state.listIndex=index;
            window.sessionStorage.setItem("listIndex",JSON.stringify(index));
          },
          setVolume(state,vol){
            state.volume=vol;
            window.sessionStorage.setItem("volume",JSON.stringify(vol));
          }
        },
        getters:{
          keywords(state){
            let keywords=state.keywords
            if(!keywords){
                keywords=JSON.parse(window.sessionStorage.getItem('keywords')|| null)
            }
            return keywords;
          },
            listOfSongs(state){
                let listSong=state.listOfSongs
                if(!listSong){
                    listSong=JSON.parse(window.sessionStorage.getItem('listOfSongs')|| null)
                }
                return listSong;
            },
            playButton(state){
                return state.playButton;
            },
            isId(state){
               return state.id
            },
            isUrl:(state)=>{
               return state.url ;
            },
            isPlay(state){
               return state.isPlay;
            },

            duration(state){
                return state.duration
            },
            curTime(state){
                return state.curTime
            },
            changeTime(state){
              return state.changeTime
            },
            title(state){
              return state.title
            },
            artist(state){
             return state.artist
            },
            picUrl(state){
              return state.picUrl;
            },
            autoNext(state){
                  return state.autoNext
            } ,
            lyric(state){
              return state.lyric
            },  //未被处理的歌词信息，
            tempList(state){
              return state.tempList
            },
            listIndex(state){
                return state.listIndex
            },
            volume(state){
                return state.volume
            }


        }
}
export default song