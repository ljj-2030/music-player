const user={
    state:{
        userId:'',
        avator:'',
    },
    mutations:{
        setUserId(state,id){
                state.userId=id;
                window.localStorage.setItem("userId",JSON.stringify(state.userId))
        },
        setAvator(state,avator){
            state.avator=avator;
            window.localStorage.setItem("avator",JSON.stringify(state.avator))
    },
    },
    getters:{
        userId(state){
            let userid=state.userId;
            if(!userid){
                userid=JSON.parse(window.localStorage.getItem("userId"))
            }
            return userid;
        },
        avator(state){
            let avator=state.avator;
            if(!avator){
                avator=JSON.parse(window.localStorage.getItem("avator"))
            }
            return avator;
        }
    }
}
export default user