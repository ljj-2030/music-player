const configure={
    state:{
            HOST:'http://localhost:8888',
            activeName:'',
            showAside:false,//是否显示播放中的歌曲列表
            loginIn:false,//是否登录
            isActive:false,//是否收藏
    },
    getters:{
        isActive(state){
            let active=state.isActive;
            if(active){
                active=JSON.parse(window.localStorage.getItem("isActive"))
            }
            return active;
        },
        loginIn:state=>{
                let login=state.loginIn;
                if(!login){
                    login=JSON.parse(window.localStorage.getItem("login"));
                }
                return login;
        },
            activeName:state=>{
                let activeName=state.activeName;
                if(!activeName){
                    activeName=window.localStorage.getItem("activeName")
                }
                return (activeName);
            },
            showAside:state=>{
                return state.showAside;
            }
    },
    mutations:{
        setShowAside:(state,show)=>{
                state.showAside=show;
        },
        setActiveName:(state,activeName)=>{
            state.activeName=activeName;
            window.localStorage.setItem("activeName",(activeName));
        },
        setLoginIn:(state,login)=>{
            state.loginIn=login;
            window.localStorage.setItem("login",(login));
        },
        setIsActive(state,active){
            state.isActive=active;
            window.localStorage.setItem("isActive",active);
        }
    }
}
export default configure;